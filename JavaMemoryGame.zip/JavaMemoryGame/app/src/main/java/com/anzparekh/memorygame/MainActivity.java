package com.anzparekh.memorygame;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToEasyMenu(View view) {
        Intent intent = new Intent(this, goToEasyMenu.class);
        startActivity(intent);
    }

    public void goToMedium(View view) {
        Intent intent = new Intent(this, MediumActivity.class);
        startActivity(intent);
    }

    public void goToHard(View view) {
        Intent intent = new Intent(this, HardActivity.class);
        startActivity(intent);
    }
}
