package com.anzparekh.memorygame;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.*;

public class EasyActivity extends AppCompatActivity {

    private long timeLeftInMilliseconds = 6 * 1000;
    boolean isTurns;
    private TextView TimeScore;
    private TextView Description;
    private ImageButton imageButton1; private ImageButton imageButton2; private ImageButton imageButton3;
    private ImageButton imageButton4; private ImageButton imageButton5; private ImageButton imageButton6;
    private ImageButton imageButton7; private ImageButton imageButton8;
    private Handler mHandler = new Handler(); private Handler afterCount = new Handler(); private Handler handler = new Handler();
    private long milltime; private long start; private long buff; private int check;
    private static Map<ImageButton, String> map;
    private long lastClickTime = 0;
    private int numTurns;
    private ImageButton tmpButton;
    private String img;

    public void startCountDownTimer() {
        TimeScore.setText("5");
        CountDownTimer countDownTimer = new CountDownTimer(timeLeftInMilliseconds, 1000) {
            @SuppressLint("SetTextI18n")
            @Override
            public void onTick(long millisUntilFinished) {
                TimeScore.setText("" + (millisUntilFinished / 1000));
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFinish() {
                if(isTurns) {
                    Description.setText("Turns:");
                    TimeScore.setText("0");
                }
                else {
                    handler = new Handler();
                    Description.setText("Time:");
                    start = SystemClock.uptimeMillis();
                    handler.postDelayed(runnable, 0);
                }
            }
        };
        countDownTimer.start();
    }
    public Runnable runnable = new Runnable() {
        @SuppressLint({"SetTextI18n", "DefaultLocale"})
        public void run() {
            milltime = SystemClock.uptimeMillis() - start;
            long update = buff + milltime;
            int sec = (int) (update / 1000);
            int min = sec / 60;
            sec = sec % 60;
            TimeScore.setText("" + min + ":" + String.format("%02d", sec));
            handler.postDelayed(this, 0);
        }
    };

    public void check() {
        if(check == 4) {
            final Intent intent = new Intent(getApplicationContext(), FinalActivity.class);
            if(!isTurns) {
                buff += milltime;
                handler.removeCallbacks(runnable);
                intent.putExtra("label", "MINUTES");
            }
            else
                intent.putExtra("label", "TURNS");
            intent.putExtra("num", "" + TimeScore.getText());
            intent.putExtra("level", "easy");
            afterCount.postDelayed(new Runnable() {
                public void run() {
                    startActivity(intent);
                }
            }, 1000);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy);
        TimeScore = findViewById(R.id.TimeScore);
        Description = findViewById(R.id.Description);
        numTurns = 0;
        Intent myIntent = getIntent();
        String theme = myIntent.getStringExtra("theme");
        isTurns = myIntent.getBooleanExtra("isTurns", false);
        String color = myIntent.getStringExtra("color");
        List<String> indices = new ArrayList<>(8);
        if(theme.equals("animals")) {
            indices.add("animal1"); indices.add("animal1"); indices.add("animal2");
            indices.add("animal2"); indices.add("animal3"); indices.add("animal3");
            indices.add("animal4"); indices.add("animal4");
        }
        else if(theme.equals("people")) {
            indices.add("person1"); indices.add("person1"); indices.add("person2");
            indices.add("person2"); indices.add("person3"); indices.add("person3");
            indices.add("person4"); indices.add("person4");
        }
        else {
            indices.add("art1"); indices.add("art1"); indices.add("art2");
            indices.add("art2"); indices.add("art3"); indices.add("art3");
            indices.add("art4"); indices.add("art4");
        }
        imageButton1 = findViewById(R.id.imageButton1); imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3); imageButton4 = findViewById(R.id.imageButton4);
        imageButton5 = findViewById(R.id.imageButton5); imageButton6 = findViewById(R.id.imageButton6);
        imageButton7 = findViewById(R.id.imageButton7); imageButton8 = findViewById(R.id.imageButton8);
        if(color.equals("red")) {
            imageButton1.setBackgroundTintList(getResources().getColorStateList(R.color.red)); imageButton2.setBackgroundTintList(getResources().getColorStateList(R.color.red));
            imageButton3.setBackgroundTintList(getResources().getColorStateList(R.color.red)); imageButton4.setBackgroundTintList(getResources().getColorStateList(R.color.red));
            imageButton5.setBackgroundTintList(getResources().getColorStateList(R.color.red)); imageButton6.setBackgroundTintList(getResources().getColorStateList(R.color.red));
            imageButton7.setBackgroundTintList(getResources().getColorStateList(R.color.red)); imageButton8.setBackgroundTintList(getResources().getColorStateList(R.color.red));
        }
        else if(color.equals("orange")) {
            imageButton1.setBackgroundTintList(getResources().getColorStateList(R.color.orange)); imageButton2.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
            imageButton3.setBackgroundTintList(getResources().getColorStateList(R.color.orange)); imageButton4.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
            imageButton5.setBackgroundTintList(getResources().getColorStateList(R.color.orange)); imageButton6.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
            imageButton7.setBackgroundTintList(getResources().getColorStateList(R.color.orange)); imageButton8.setBackgroundTintList(getResources().getColorStateList(R.color.orange));
        }
        else if(color.equals("yellow")) {
            imageButton1.setBackgroundTintList(getResources().getColorStateList(R.color.yellow)); imageButton2.setBackgroundTintList(getResources().getColorStateList(R.color.yellow));
            imageButton3.setBackgroundTintList(getResources().getColorStateList(R.color.yellow)); imageButton4.setBackgroundTintList(getResources().getColorStateList(R.color.yellow));
            imageButton5.setBackgroundTintList(getResources().getColorStateList(R.color.yellow)); imageButton6.setBackgroundTintList(getResources().getColorStateList(R.color.yellow));
            imageButton7.setBackgroundTintList(getResources().getColorStateList(R.color.yellow)); imageButton8.setBackgroundTintList(getResources().getColorStateList(R.color.yellow));
        }
        map = new HashMap<>();
        ImageButton[] arr = new ImageButton[8];
        arr[0] = imageButton1; arr[1] = imageButton2; arr[2] = imageButton3; arr[3] = imageButton4;
        arr[4] = imageButton5; arr[5] = imageButton6; arr[6] = imageButton7; arr[7] = imageButton8;
        for(int x = 0; x < 8; ++x) {
            int arrIndex = (int)(indices.size() * Math.random());
            String s = indices.get(arrIndex);
            map.put(arr[x], s);
            indices.remove(arrIndex);
        }
        startCountDownTimer();
        afterCount.postDelayed(new Runnable() {
            public void run() {
                imageButton1.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton1.setImageResource(getResources().getIdentifier(map.get(imageButton1), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton1;
                            img = map.get(imageButton1);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton1), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton1.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton1.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton2.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton2.setImageResource(getResources().getIdentifier(map.get(imageButton2), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton2;
                            img = map.get(imageButton2);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton2), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton2.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton2.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton3.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton3.setImageResource(getResources().getIdentifier(map.get(imageButton3), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton3;
                            img = map.get(imageButton3);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton3), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton3.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton3.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton4.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton4.setImageResource(getResources().getIdentifier(map.get(imageButton4), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton4;
                            img = map.get(imageButton4);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton4), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton4.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton4.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton5.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton5.setImageResource(getResources().getIdentifier(map.get(imageButton5), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton5;
                            img = map.get(imageButton5);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton5), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton5.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton5.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton6.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton6.setImageResource(getResources().getIdentifier(map.get(imageButton6), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton6;
                            img = map.get(imageButton6);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton6), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton6.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton6.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton7.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton7.setImageResource(getResources().getIdentifier(map.get(imageButton7), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton7;
                            img = map.get(imageButton7);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton7), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton7.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton7.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
                imageButton8.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 200)
                            return;
                        lastClickTime = SystemClock.elapsedRealtime();
                        imageButton8.setImageResource(getResources().getIdentifier(map.get(imageButton8), "drawable", getPackageName()));
                        if (numTurns % 2 == 0) {
                            tmpButton = imageButton8;
                            img = map.get(imageButton8);
                            TimeScore.setText(String.valueOf(numTurns / 2 + 1));
                        } else {
                            if (!(Objects.equals(map.get(imageButton8), img))) {
                                mHandler.postDelayed(new Runnable() {
                                    public void run() {
                                        tmpButton.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                        imageButton8.setImageResource(getResources().getIdentifier("transparent.png", "drawable", getPackageName()));
                                    }
                                }, 500);
                            } else {
                                tmpButton.setOnClickListener(null);
                                imageButton8.setOnClickListener(null);
                                check++;
                            }
                        }
                        check();
                        numTurns++;
                    }
                });
            }
        }, 6000);
    }
}
