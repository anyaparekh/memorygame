package com.anzparekh.memorygame;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FinalActivity extends AppCompatActivity {

    public void goToMainActivity(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        TextView label = findViewById(R.id.label2);
        TextView num = findViewById(R.id.num);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Intent myIntent = getIntent();
        String val = myIntent.getStringExtra("num");
        if(myIntent.getStringExtra("label").equals("MINUTES")) {
            if(Integer.parseInt(val.substring(0, val.length()-3)) == 0)
                label.setText("SECONDS");
            else {
                label.setText("MINUTES");
            }
        }
        else
            label.setText("TURNS");
        num.setText(val);
        String level = myIntent.getStringExtra("level");
        button5.setText("play another " + level + " game");
        if(level.equals("easy")) {
            button5.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(), goToEasyMenu.class);
                    startActivity(intent);
                }
            });
        }
        /* do for the medium level and hard level */
    }
}
