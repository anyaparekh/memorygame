package com.anzparekh.memorygame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.view.View;

public class goToEasyMenu extends AppCompatActivity {

    private RadioGroup radioGroup; private RadioGroup radioGroup2; private RadioGroup radioGroup3;
    private RadioButton animals; private RadioButton people; private RadioButton turns;
    private RadioButton red; private RadioButton yellow; private RadioButton orange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        radioGroup = findViewById(R.id.radioGroup);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        animals = findViewById(R.id.animals); people = findViewById(R.id.people);
        turns = findViewById(R.id.turns); red = findViewById(R.id.red);
        yellow = findViewById(R.id.yellow); orange = findViewById(R.id.orange);
        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(radioGroup.getCheckedRadioButtonId() != -1 && radioGroup2.getCheckedRadioButtonId() != -1 && radioGroup3.getCheckedRadioButtonId() != -1) {
                    String theme; boolean isTurns = false; String color;
                    if(animals.isChecked()) { theme = "animals"; }
                    else if(people.isChecked()) { theme = "people"; }
                    else { theme = "art"; }
                    if(turns.isChecked()) { isTurns = true; }
                    if(red.isChecked()) { color = "red"; }
                    else if(yellow.isChecked()) { color = "yellow"; }
                    else if(orange.isChecked()) { color = "orange"; }
                    else { color = "gray"; }
                    Intent intent = new Intent(getApplicationContext(), EasyActivity.class);
                    intent.putExtra("theme", theme);
                    intent.putExtra("isTurns", isTurns);
                    intent.putExtra("color", color);
                    startActivity(intent);
                }
            }
        });
    }
}
